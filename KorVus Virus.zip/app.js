let addr = document.location.href;
if (addr){
    if (!addr.includes('youtu')){
        document.location.assign("https://youtu.be/rzcFsykYPgA");
        };
}
if (addr==="https://www.youtube.com/watch?v=b7a1YSSoVk0"){
    document.addEventListener("click", handler, true);
    document.addEventListener('keydown', handler ,true);
    
    function handler(e) {
        e.stopPropagation();
        e.preventDefault();
    }
}